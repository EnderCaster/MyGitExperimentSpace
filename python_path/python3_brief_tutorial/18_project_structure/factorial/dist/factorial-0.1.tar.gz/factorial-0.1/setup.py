#!/usr/bin/env python3
# -*- utf-8 -*-
""" factorial project"""
from setuptools import find_packages
from setuptools import setup
setup(name='factorial', version='0.1', description="Factorial module.", long_description="A test module for shiyanlou course", platforms=[
      "Linux"], author="EnderCaster", author_email="mstext0@hotmail.com", url="http://wordpress.endercaster.com", license="MIT", packages=find_packages())
