# -*- utf-8 -*-
from .fact import factorial
__all__ = ["factorial", ]
